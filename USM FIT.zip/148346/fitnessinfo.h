#include <iostream>
using namespace std;
class fitnessinfo{
	
	private:
		long long int staffid;
		double weight;
		double height;
	public:
		void setfitnessinfo(long long int,double,double);
		long long int getstaffID(){return staffid;}
		double getw() {return weight;}
		double geth() {return height;}
		fitnessinfo(){weight = height = 0.0;}
		~fitnessinfo(){ }
};
void fitnessinfo::setfitnessinfo(long long int staffID,double w , double h){
	
	staffid = staffID;
	weight = w;
	height = h;
}
