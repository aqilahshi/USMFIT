#include <iostream>
using namespace std;
class data:public personalinfo{
	
	private:
		int age;
		double BMI;
		double BMR;
		double RMR;
		string status1;
		fitnessinfo obj;
	public:
		void setdata1(long long int,string,string);
		void setdata2(long long int,double,double);
		double setweight();
		double setheight();
		int getage1(){return age;}
		double getbmi(){return BMI;}
		double getbmr(){return BMR;}
		double getrmr(){return RMR;}
		string getstatus(){return status1;}
		void calc_age();
		void calc_dob();
		void calc_bmi();
		void calc_bmrRmr();
		void status();
		void displaydata();
		void display_data();
		data(){age = 0;BMI = BMR = RMR = 0.0;status1 =" ";}
		~data(){ }
		friend void search(data fit[],int &z,int &add);	
};
void data::setdata1(long long int ID,string n,string g){
	
	setpersonalinfo(ID,n,g);
	
}
void data::setdata2(long long int staffID,double w,double h){
	
	obj.setfitnessinfo(staffID,w,h);
}
double data::setweight(){
	
	return obj.getw();
}
double data::setheight(){
	
	return obj.geth();
}
void data::calc_age(){
	
	int index = 12;
	int a = 10;
	int py = 2020 ;
	int year;
	int icnum [index] ={0};
	long long int ic = getID();
	
		for(int i=0; i<index; i++){
		
		icnum[i] = ic % a;
		ic=ic/a;
	}
	
	year = icnum[11]*10 + icnum[10];
	if (year <= 20)
	
		age = py - (2000 + year);
				
	else
		age = py -(1900 + year);
  		
  	
}
void data::calc_dob(){
	
	int index=12; 
	int icnum [index] = {0}; 
	int a = 10; 
	long long int ic = getID();
	
	for(int i=0; i<index; i++){
		
		icnum[i] = ic % a;
		ic = ic / a;
	}
	cout << icnum[7] << icnum[6]<< "/ " << icnum[9] << icnum[8] << "/" << icnum[11] << icnum[10] << endl;
	
}
void data::calc_bmi(){
	
	BMI = obj.getw()/(obj.geth()*obj.geth())*10000;
			
}	
void data::calc_bmrRmr(){
	
		//to calculate bmr and rmr for man
		if(getg()=="Male"){
				
			BMR=10 * obj.getw() + 6.25 * obj.geth() - 5 * age + 5;
			RMR=88.362 + (13.397 * obj.getw()) + (4.799 * obj.geth())-(5.677 * age);
		}
			
		//to calculate bmr and rmr for woman
		else {
				
			BMR=10 * obj.getw() + 6.25 * obj.geth()- 5 * age - 161;
			RMR=447.593 + (9.247 * obj.getw()) + (3.098 * obj.geth()) - (4.330 * age);
		}
}
void data::status(){
	
	if(BMI >=30)
		status1="obese";
				
	else if(BMI>=25 && BMI<30)
		status1="overweight";
			
	else if(BMI>=20 && BMI<25)
		status1="normal weight";
			
	else
		status1="under weight";
		
}
void data::displaydata(){
	
	cout << fixed << showpoint << setprecision(2);
	cout.width(40);
	cout <<left << getn() ;
	cout.width(20);
	cout << getID() ;
	cout.width(10);
	cout << getg() << "\t"<< age << "\t" << obj.getw()<< "\t" << obj.geth()<< "\t" << BMI << "\t";
	cout.width(15);
	cout << BMR ;
	cout.width(15);
	cout << RMR ;
	cout.width(20);
	cout <<status1;	
			    	    
}
void data::display_data(){
	
	cout << fixed << showpoint << setprecision(2);
	cout << "NAME:" << getn() << endl;
	cout << "STAFF ID: "<< getID() << endl;
	cout << "GENDER:" << getg() << endl;
	cout << "AGE:" << age << endl;
	cout << "WEIGHT:" << obj.getw() << endl;
	cout << "HEIGHT:" << obj.geth() << endl;
	cout << "BMI:" << BMI << endl;
	cout << "BMR:" << BMR << endl;
	cout << "RMR:" << RMR << endl;
	cout << "STATUS:" << status1 << endl;
	
}
