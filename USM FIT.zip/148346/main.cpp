#include <iostream>
#include <windows.h>
#include <fstream>
#include <iomanip>
#include "personalinfo.h"
#include "fitnessinfo.h"
#include "data.h"
using namespace std;
//function prototype
void search(data fit[],int &z,int &add);	
void intruction();
	
int main(){
	
	long long int id,proceed,staffic;
	double weight,height,bmi,bmr,rmr;
	const int n = 1000;
	data fit[n];
	string name,gender,spacing,status;
	int age,age1,dup;
	int i=0;
	int j=0;
	int choice,choose,num,press,month,day,state;
	int add = 0;
	int z = 10;
	int icnum[12] ={0}; 
	
	//-------READ THE TEXT FILE-------
	ifstream inData;
	inData.open("PersonalInfo.txt");

	while(!inData.eof())
	{
		if(inData.eof()==true)
		break;
		
		else
		{
			inData>>id;
			getline(inData,spacing,'\t');
			getline(inData,name,'\t');
			getline(inData,gender);
			fit[i].setdata1(id,name,gender);//to set data into object
			i++;
		}
	}//end while
	
	inData.close();
	
	inData.open("FitnessInfo.txt");

	while(!inData.eof())
	{
		if(inData.eof()==true)
		break;
							
		else
		{
			inData >> id >> weight >> height;
			fit[j].setdata2(id,weight,height);//to set data into object
			j++;
		}	
	}//end while
	
	inData.close();
	
	
	do{
		//-------DISPLAY MENU-------
		intruction();
		cin >> choice;
		if(!cin){//validation for user that enter the choice without using number
			cout << "\n\t\t\t 			INVALID DATA TYPE.PLEASE REENTERED AGAIN USING number ONLY!\n";
			Sleep(1000);
			cin.clear();
			cin.ignore(100000,'\n');
			cout <<"\n\t\t\t 					Your choice is : ";
			cin >> choice;	
		}
		//-------PROCESS THE MENU SELECTION------
		switch(choice)
		{
			//-------DISPLAY DATA-------
			case 1:
			{
				system("CLS");
				i = j;
				
				cout << "  \nNAME   "<<" "<<"\t\t\t\tID STAFF" <<" "<< "\tGENDER"<< " "<< "\t\t AGE"<< " "<< "\tWEIGHT" <<" "<<"\tHEIGHT"<<
				" "<<"\t BMI"<<" "<<"\tBMR"<<" "<<" \t\tRMR"<<" "<<"\t\tCATEGORY"<<"\t DOB\n" << endl;	 
				
				for(int i=0;i<(z+add);i++){
					fit[i].calc_age();
					fit[i].calc_bmi();
					fit[i].calc_bmrRmr();
					fit[i].status();
					fit[i].displaydata();
					fit[i].calc_dob();
				}
				
				cout << "\n\n";
				system("pause");	
				break;
						
			}//end case 1
		
			//-------SEARCH SPECIFIC INFORMATION-------
			case 2:
			{	
				system("CLS");
				
				do{

					search(fit,z,add);
					cout<<"\nDo you want to search more information?"<<endl;
					cout<<"PRESS 1-TO CONTINUE"<<endl;
					cout<<"PRESS 2-TO BACK TO MAIN MENU"<<endl;
					cout<<"ENTER YOUR CHOICE:";
					cin >>press;
					
				}while(press!=2);
				
				cout << "\n\n";	
				system("pause");	
				break;
				
			}//end case 2
			
			//-------ADD INFORMATION-------
			case 3:
			{	
				system("CLS");
				cout <<"HOW MANY STAFF TO ADD : ";   
				cin	 >>add;
				if(!cin){//validation for user that enter the choice without using number
					cout << "INVALID DATA TYPE.PLEASE REENTERED AGAIN USING number ONLY!";
					Sleep(1000);
					cin.clear();
					cin.ignore(100000,'\n');
					system("cls");
					cout <<"HOW MANY STAFF TO ADD : ";   
					cin	 >>add;
				}
				for(int i=z;i<(z+add);i++){
				cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
				cin  >> id;
				staffic = id;
				
				do{
					staffic = id;
					for(int i=0;i<(z+add);i++){
						dup=0;
						if(staffic==fit[i].getID())//validation if the user prompt the id that already exist
						{
							dup=1;
							cout << "invalid id"<<endl;
							Sleep(1000);
							system("CLS");
							cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
							cin  >> id;
							staffic = id;
						}
					}
				}while(dup==1);
				
				do{	
					staffic=id;
					for(int i=0;i<12;i++){//calculation to spllit the id
						icnum[i]=staffic%10;
						staffic=staffic/10;
					}
					month= icnum[9]*10 + icnum[8];
					dup=0;
					if(month<0||month>12){//validation for month
						dup=1;
						cout << "Your month has exceed the limit.Please reenter again less than 12"<<endl;
						Sleep(1000);
						system("CLS");
						cout << "\nSTAFF ID (12 DIGITS WITHOUT '-') :";
						cin  >> id;	
						staffic = id;
					}
					else
						break;
				}while(dup==1);
	
				do{	
					staffic=id;
					for(int i=0;i<12;i++){//calculation to spllit the id
						icnum[i]=staffic%10;
						staffic=staffic/10;
					}
					month= (icnum[9]*10)+ icnum[8];
					day = (icnum[7]*10) + icnum[6];
					dup=0;
					if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
						if(day>31){//validation for day
							dup=1;
							cout << "\nYour day has exceed the limit.Please reenter again less than 31"<<endl;
							Sleep(1000);
							system("CLS");
							cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
							cin  >> id;	
							staffic = id;	
						}
						else
							break;
					}
					else if(month==4||month==6||month==9||month==11){
						if(day>30){//validation for day
							dup=1;
							cout << "\nYour day has exceed the limit.Please reenter again less than 30"<<endl;
							Sleep(1000);
							system("CLS");
							cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
							cin  >> id;	
							staffic = id;
						}
						else
							break;
					}
					else if(month==2){
						if(day>29){//validation for day
							dup=1;
							cout << "\nYour day has exceed the limit.Please reenter again less than 29"<<endl;
							Sleep(1000);
							system("CLS");
							cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
							cin  >> id;	
							staffic = id;
						}
						else
							break;
					}
					
				}while(dup==1);	
				
				do{
					staffic=id;
					for(int i=0;i<12;i++){//calculation to spllit the id
						icnum[i]=staffic%10;
						staffic=staffic/10;
					}
					state=(icnum[5]*10)+icnum[4];
					dup=0;
					if(state==17||state==18||state==19||state==20||state>59){//validation for state
						dup=1;
						cout << "\nYour state for id is not exist.Please reenter again your staff id"<<endl;
						Sleep(1000);
						system("CLS");
						cout << "\nSTAFF ID(12 DIGITS WITHOUT-) :";
						cin  >> id;	
						staffic = id;
					}
				}while(dup==1);
				cout <<"\nNAME:";
				cin.ignore();
				getline(cin,name);//to insert name with space
				
				cout << "\nGENDER(Male/Female) :";
				cin  >> gender;
				while(gender!="Male" && gender!="Female"){//validation for gender
					cout <<"Invalid gender."<<endl;
					Sleep(1000);
					system("CLS");
					cout <<"Enter your gender again:";
					cin >> gender;	
				}
				cout << "\nWEIGHT(IN KG) :";
				cin  >> weight;
				while(weight<40||weight>150){//validation for weight
					cout<<"Range weight is not possible."<<endl;
					Sleep(1000);
					system("CLS");
					cout <<"Enter your weight again:";
					cin >> weight;
				}
				cout << "\nHEIGHT(IN CM) :";
				cin  >> height;
				while(height<150||height>190){//validation for height
					cout<<"Range height is not possible."<<endl;
					Sleep(1000);
					system("CLS");
					cout <<"Enter your height again:";
					cin >> height;
				}
				fit[i].setdata1(id,name,gender);
				fit[i].setdata2(id,weight,height);
				}//end for loop
				cout << endl;
				cout << "\n\n";
				system("pause");
				break;
				
			}//end case 3
			
			//-------STATISTIC INFORMATION-------
			case 4:	
			{
				int obese1=0,obese2=0,overweight1=0,overweight2=0,normalweight1=0,
				normalweight2=0,underweight1=0,underweight2=0;
				
				system("CLS");

				for(int i=0;i<(z+add);i++)
				{
					if(fit[i].getbmi()>=30  && fit[i].getg () == "Male")
					
						obese1++;
			
					else if(fit[i].getbmi() >=30 && fit[i].getg ()== "Female")
					
						obese2++;
				
					else if(fit[i].getbmi() >=25 && fit[i].getbmi()<30 && fit[i].getg () == "Male")
					
						overweight1++;
			
					else if(fit[i].getbmi() >=25 && fit[i].getbmi()<30 && fit[i].getg ()== "Female")
					
						overweight2++;
			
					else if(fit[i].getbmi() >=20 && fit[i].getbmi()<25 && fit[i].getg () == "Male")
					
						normalweight1++;
		
					else if(fit[i].getbmi() >=20 && fit[i].getbmi()<25 && fit[i].getg ()== "Female")
					
						normalweight2++;
			
					else if(fit[i].getbmi()<20 && fit[i].getg () == "Male")
					
						underweight1++;
			
					else if(fit[i].getbmi()<20 && fit[i].getg ()== "Female")
					
						underweight2++;
				}
	
				cout << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				cout << endl;
				cout << "\t\t\t ****************************************************************************************"<<endl;
				cout << "\t\t\t *      STATUS      |       MALE       |       FEMALE           |      TOTAL            *"<<endl;
				cout << "\t\t\t ****************************************************************************************"<<endl;
				cout << "\t\t\t *      OBESE       | "  <<obese1<<"\t\t\t|"<<obese2<<"\t\t\t|"<<obese1+obese2<<"\t\t\t*"<<endl;
				cout <<	"\t\t\t *     OVERWEIGHT   | "  <<overweight1<<"\t\t\t|"<<overweight2<<"\t\t\t|"<<overweight1+overweight2<<"\t\t\t*"<<endl;
				cout << "\t\t\t *   NORMAL WEIGHT  | "  <<normalweight1<<"\t\t\t|"<<normalweight2<<"\t\t\t|"<<normalweight1+normalweight2<<"\t\t\t*"<<endl;
				cout << "\t\t\t *   UNDER WEIGHT   | "  <<underweight1<<"\t\t\t|"<<underweight2<<"\t\t\t|"<<underweight1+underweight2<<"\t\t\t*"<<endl;
				cout <<"\t\t\t *****************************************************************************************"<<endl;
				cout <<endl;
				
				cout << "\n\n";
				system("pause");	
				break;
				
			}//end case 4
			
			//-------SEARCH COMBINATIONAL-------
			case 5:
			{	do{
				do{
					system("CLS");
					cout << "Choose the following formarts "<< endl;
					cout << "[1]- AGE > && BMI > "<< endl;
					cout << "[2]- AGE > && BMI <"<< endl;
					cout << "[3]- AGE < && BMI > "<< endl;
					cout << "[4]- AGE < && BMI < "<< endl;
					cout << "Enter your choice : ";
					cin  >> choose;
					cout << endl;
					if(!cin){//validation for user that enter the choice without using number
						cout << "INVALID DATA TYPE.PLEASE REENTERED AGAIN USING number ONLY!";
						Sleep(1000);
						cin.clear();
						cin.ignore(100000,'\n');
						system("CLS");
						cout << "Enter your choice : ";
						cin  >> choose;
						cout << endl;
					}
					else if(choose<1 || choose>4)
						cout<< "INVALID NUMBER... ENTER AGAIN\n"<<endl;
					
					Sleep(1000);
					}while(choose<1 || choose>4);
					
					cout << "Enter your age range :";
					cin  >> age1;
					cout << endl;
					while (age1<18||age1>60){//validation for age
						cout << "Range age is not possible.";
						Sleep(1000);
						system("CLS");
						cout << "Enter your age again:";
						cin >> age1;
					}
					cout << "Enter your BMi range :" ;
					cin  >> bmi;
					while (bmi<0){//validation for bmi
						cout << "Range BMI is not possible";
						Sleep(1000);
						system("CLS");
						cout << "Enter your BMI again:";
						cin >> bmi;
					}
					
					if (choose == 1){
					
						for(int i=0;i<z+add;i++){
						
							if(fit[i].getage1() >=age1 && fit[i].getbmi() >= bmi){
							
								fit[i].display_data();
								cout << "DATE OF BIRTH:";
								fit[i].calc_dob();
								cout << endl;
							}
						}
					}//end choose 1
					else if (choose == 2){
					
						for(int i=0;i<z+add;i++){
						
							if(fit[i].getage1() >=age1 && fit[i].getbmi() <= bmi){
							
								fit[i].display_data();
								cout << "DATE OF BIRTH:";
								fit[i].calc_dob();
								cout << endl;
							}
						}
					}//end choose 2
					else if (choose == 3){
					
						for(int i=0;i<z+add;i++){
						
							if(fit[i].getage1() <=age1 && fit[i].getbmi() >= bmi){
							
								fit[i].display_data();
								cout << "DATE OF BIRTH:";
								fit[i].calc_dob();
								cout << endl;
							}
						}
					}//end choose 3
					else if (choose == 4){
					
						for(int i=0;i<z+add;i++){
						
							if(fit[i].getage1() <=age1 && fit[i].getbmi() <= bmi){
							
								fit[i].display_data();
								cout << "DATE OF BIRTH:";
								fit[i].calc_dob();
								cout << endl;
							}
						}
					}//end choose 4
				
					cout<<"\nDo you want to search more information?"<<endl;
					cout<<"PRESS 1-TO CONTINUE"<<endl;
					cout<<"PRESS 2-TO BACK TO MAIN MENU"<<endl;
					cout<<"ENTER YOUR CHOICE:";
					cin >>press;
					}while(press!=2);
				
					cout << "\n\n";
					system("pause");		
					break;
			}//end case 6
			
			//-------UPDATE INFORMATION-------
			case 6:
			{	
				system("CLS");

				do{
					cout << "Staff id : ";
					cin >> proceed;
					while(proceed<0||proceed>999999999999){//validation for user that enter more than 12 digits
		
						cout<<"THE ID HAS EXCEED LIMIT"<<endl;
						cout<<"Please enter again"<<endl;
						Sleep(1000);
						system("CLS");
						cout << "Staff id : ";
						cin >> proceed;
					}
					for(i=0;i<(z+add);i++){
					
						if(fit[i].getID()==proceed){
							
							proceed=fit[i].getID();
							weight=fit[i].setweight();
							height=fit[i].setheight();
							fit[i].display_data();
							cout << "DATE OF BIRTH:";
							fit[i].calc_dob();
							cout << endl;
							do{
								cout << "Choose the following options below to change or update your information" << endl;
								cout << "[1]-YOUR WEIGHT" << endl;
								cout << "[2]-YOUR HEIGHT" << endl;
								cout << "Enter Your Choice:";
								cin  >> num;
								cout << endl;
								if(!cin){//validation for user that enter the choice without using number
									cout << "INVALID DATA TYPE.PLEASE REENTERED AGAIN USING number ONLY!";
									Sleep(1000);
									cin.clear();
									cin.ignore(100000,'\n');
									system("cls");
									cout << "Enter Your Choice:";
									cin  >> num;
									cout << endl;
								}
								else if(num<1 || num>2)
									cout<< "INVALID NUMBER... ENTER AGAIN\n"<<endl;
					
								Sleep(1000);
								}while(num<1 || num>2);
								
								if(num==1){
									cout << "Enter Your New Weight : ";
									cin  >> weight;
									while(weight<40||weight>150){//validation for weight
										cout<<"Range weight is not possible."<<endl;
										Sleep(1000);
										system("CLS");
										cout <<"Enter your weight again:";
										cin >> weight;
									}
									fit[i].setdata2(id,weight,height);
									break;
								}
							
								else if(num==2){
									cout << "Enter Your New Height : ";
									cin  >> height;
									while(height<150||height>190){//validation for height
										cout<<"Range height is not possible."<<endl;
										Sleep(1000);
										system("CLS");
										cout <<"Enter your height again:";
										cin >> height;
									}
									fit[i].setdata2(id,weight,height);
									break;
								}
						}
						else if(fit[i].getID()!=proceed && i==((z+add)-1))
							cout<<"THE ID IS NOT EXIST.PLEASE ENTER AGAIN."<<endl;
							
					}//end for loop
				
					cout<<"\nDo you want to update your information?"<<endl;
					cout<<"PRESS 1-TO CONTINUE"<<endl;
					cout<<"PRESS 2-TO BACK TO MAIN MENU"<<endl;
					cout<<"ENTER YOUR CHOICE:";
					cin >>press;
				}while(press!=2);
			
			cout << "\n\n";	
			system("pause");		
			break;		
			}//end case 6
			
			//-------OUTPUT FILE-------
			case 7:
			{
				ofstream outData;
				outData.open("outputfile.txt");
				system("CLS");
				for(i=0;i<(z+add);i++){
					name=fit[i].getn();
					gender=fit[i].getg();
					id=fit[i].getID();
					weight=fit[i].setweight();
					height=fit[i].setheight();
					age=fit[i].getage1();
					bmi=fit[i].getbmi();
					bmr=fit[i].getbmr();
					rmr=fit[i].getrmr();
					status=fit[i].getstatus();
					
					outData << name<< "\t "<< id << "\t " << gender <<"\t "<< age <<"\t "<< weight<<"\t "
					<< height<<"\t "<< bmi<<"\t "<< bmr<<"\t "<< rmr<<"\t" << status<<"\t" <<endl;
					
				}
				outData.close();
				cout << "\n\n";
				system("pause");		
				break;
				
			}//end case 6
			case 8:
			{
				choice=8;
				system("pause");
				break;
			}
		
		default:cout<<"\t\t\t 				YOUR CHOICE IS NOT VALID...PLEASE ENTER AGAIN\n";
		Sleep(1000);
			
		}//end switch
	
	}while(choice!=8);
	
}//end main
	void search(data fit[],int &z,int &add){
		
		long long int specific;
	do{	
		cout << "ENTER YOUR STAFF ID : ";
		cin >> specific;
		if(specific<0||specific>999999999999){//validation for user that enter more than 12 digits
		
			cout<<"THE ID HAS EXCEED LIMIT"<<endl;
			cout<<"Please enter again"<<endl;
			Sleep(1000);
			system("CLS");
		}
	}while(specific<0||specific>999999999999);
	
		for(int i=0;i<(z+add);i++){
				
			if(fit[i].getID()==specific){
						
		    	fit[i].display_data();
				cout << "DATE OF BIRTH:";
				fit[i].calc_dob();
				break;
			}
			else if (fit[i].getID()!=specific && i==((z+add)-1))
							
				cout<<"THIS ID IS NOT EXIST.PLEASE ENTER AGAIN."<<endl;
		}
		
	}

	void intruction(){
	   system("CLS");
	  cout <<endl<<endl;
	  cout <<"\t\t\t\t\t\t******************************************************************";
	  cout <<"\n\t\t\t						LET'S GET FIT"<<endl;
	  cout <<"\t\t\t\t\t\t******************************************************************\n";
	  cout <<"\t\t\t					Welcome to Let's Get Fit"<<endl<<endl;
	  cout <<"\t\t\t\t   			 	Choose the following options: "<<endl;
	  cout <<"\t\t\t 					[1] DISPLAY FILE\n";
	  cout <<"\t\t\t				 	[2] SEARCH INFORMATION\n";
	  cout <<"\t\t\t 					[3] ADD STAFF\n";
	  cout <<"\t\t\t				 	[4] STATISTIC INFORMATION\n";
	  cout <<"\t\t\t 					[5] SEARCH COMBINATIONAL\n";
	  cout <<"\t\t\t 					[6] UPDATE INFORMATION\n";
	  cout <<"\t\t\t 					[7] OUTPUT FILE\n";
	  cout <<"\t\t\t 					[8] EXIT\n";
	  cout <<"\t\t\t 					Your choice is : ";
	  
	}	
	

