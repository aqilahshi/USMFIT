#include <iostream>
using namespace std;

class personalinfo{
	
	private:
		long long int id;
		string name;
		string gender;
	public:
		void setpersonalinfo(long long int,string,string);
		long long int getID() {return id;}
		string getn() {return name;}
		string getg() {return gender;}
		personalinfo() {name = " "; id = 0; gender = " ";}
		~personalinfo(){ }
		
};
void personalinfo::setpersonalinfo(long long int ID,string n,string g){
	
	id = ID;
	name = n;
	gender = g;
	
}
